<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $useremail = DB::table('users')->select('email')->where('email', '=', $request->email)->first();
        if ($useremail) {
            return response()->json([
                'message' => 'already',
            ]);
        } else {
            $user = new User();
            $user->name = $request->name;
            $user->passport_no = $request->passport_no;
            $user->agent_code = $request->agent_code;
            $user->phone_no = $request->phone_no;
            $user->email = $request->email;
            $user->dropdown_menu = $request->dropdown_menu;
            $user->save();

            if ($user) {
                return response()->json([
                    'status' => 200,
                ]);
            }

            // Send Mail to Customers
            //   $data = [
            //     'name' => $user->name,
            // ];
            $user['to'] = $user->email;
            Mail::send('mails.registeration_mail', function ($messages) use ($user) {
                $messages->to($user['to'], 'email');
                $messages->subject('Registeration Confirmed', $user['to']);
            });
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
