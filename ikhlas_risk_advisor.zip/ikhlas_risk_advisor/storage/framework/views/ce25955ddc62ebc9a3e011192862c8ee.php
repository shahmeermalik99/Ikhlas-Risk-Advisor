<?php $__env->startSection('content'); ?>
    <main class="register-main pt-4">
        <div class="container-fluid px-lg-5">
            <div class="row">
                <div class="col-xl-7 text-center pe-lg-0">
                    <img src="<?php echo e(asset('assets/img/logo.png')); ?>" class="register-logo" alt="">
                    <div class="invited-section">
                        <h2>You are Invited!</h2>
                        <h3>UNLEASH YOUR POTENTIAL WITH <br> TAKAFUL IKHLAS GENERAL BERHAD</h3>
                        <p>Takaful IKHLAS General is launching the IKHLAS Risk Advisor Program and would like to invite all
                            agents to be part of this spectacular evening.</p>
                        <p>Details of this event are as follows:</p>
                        <strong> Date : 20 May 2023, Saturday</strong> <br>
                        <strong> Time : 2.00 pm - 11.00 pm. </strong> <br>
                        <strong> Venue : Bangi Avenue Convention Centre (BACC) </strong> <br> <br>
                        <p class="mb-0">Seats are limited, so register now to unleash your potential.</p>
                    </div>
                    <button class="popup-btn">Register Now</button>
                </div>
                <div class="col-xl-5 pt-5 mt-5">
                    <div class="register-form mt-5">
                        <form action="">
                            <h4>Register Your Interest</h4>
                            <div class="mb-2">
                                <input type="text" class="custom-input" name="name" id="name"
                                    placeholder="Full Name as per IC">
                                    <small class="text-danger mt-1"></small>
                                    <input type="hidden" id="_token" name="_token"
                                                    value="<?php echo e(csrf_token()); ?>" />
                            </div>
                            <div class="mb-2">
                                <input type="text" class="custom-input" name="passport_no" id="passport_no"
                                    placeholder="NRIC / Passport No">
                                    <small class="text-danger mt-1"></small>
                            </div>
                            <div class="mb-2">
                                <input type="text" class="custom-input" name="agent_code" id="agent_code"
                                    placeholder="Agent Code">
                                    <small class="text-danger mt-1"></small>
                            </div>
                            <div class="row">
                                <div class="col-7">
                                    <div class="mb-3">
                                        <input type="text" class="custom-input" name="phone_no" id="phone_no"
                                            placeholder="Phone Number">
                                            <small class="text-danger mt-1"></small>
                                    </div>
                                </div>
                                <div class="col-5 ps-0">
                                    <div class="mb-2">
                                        <input type="email" class="custom-input form-control" name="email"
                                            id="email" placeholder="Email">
                                            <small class="text-danger mt-1"></small>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-2">
                                <select name="dropdown_menu" id="dropdown_menu" class="custom-input" id="">
                                    <option selected value="">Ikhlas Risk Advisor</option>
                                    <option value="1">Servicing Branch</option>
                                    <option value="2">Servicing Branch</option>
                                    <option value="3">Servicing Branch</option>
                                </select>
                                <small class="text-danger mt-1"></small>
                            </div>
                            <div class="mb-2">
                                <button class="submit-btn" id="add_submit_btn">Submit</button>
                            </div>
                            <small>Drop us an email at admin@ikhlasadvisor.com if you need any assistance.</small>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <div class="overlay"></div>

    <div class="thanku-popup" id="thanku-popup">
        <h2>Thank you for your interest</h2>
        <p>We will confirm your registration status via email nearing to the event date.</p>
        <div class="mt-5 pt-5">
            <button class="close-btn" onclick="reload()">Close</button>
        </div>
    </div>


    <script>
        const popupBtn = document.querySelector(".popup-btn")
        const registerPopup = document.querySelector(".register-form")
        const overlay = document.querySelector(".overlay")
        const closeBtn = document.querySelector(".close-btn")
        const thankuPopup = document.querySelector(".thanku-popup")

        popupBtn.addEventListener("click", () => {
            registerPopup.style.top = "50%"
            registerPopup.style.left = "50%"
            registerPopup.style.transform = "translate(-50%, -50%)"
            overlay.style.opacity = "1"
            overlay.style.visibility = "visible"
        })

        closeBtn.addEventListener("click", () => {
            thankuPopup.style.top = "-2000px"
        })
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script>
        $("#add_submit_btn").on('click', function(e) {
            e.preventDefault();
            const Fieldvalue = [];
            Fieldvalue[0] = document.querySelector("#name");
            Fieldvalue[1] = document.querySelector("#passport_no");
            Fieldvalue[2] = document.querySelector("#agent_code");
            Fieldvalue[3] = document.querySelector("#phone_no");
            Fieldvalue[4] = document.querySelector("#email");
            Fieldvalue[5] = document.querySelector("#dropdown_menu");
            let error = 0;
            for (let i = 0; i <= Fieldvalue.length - 1; i++) {
                if (Fieldvalue[i].value == '') {
                    Fieldvalue[i].nextElementSibling.innerHTML = "This field is required";
                    error++;
                } else {
                    Fieldvalue[i].nextElementSibling.innerHTML = "";
                }
            }

        if (error == 0) {
            console.log('done');
            let name = $("#name").val();
            let passport_no = $("#passport_no").val();
            let agent_code = $("#agent_code").val();
            let phone_no = $("#phone_no").val();
            let email = $("#email").val();
            let dropdown_menu = $("#dropdown_menu").val();
            let _token = $("#_token").val();
            console.log(_token);
            $.ajax({
                url: "<?php echo e(url('registeration')); ?>",
                type: "POST",
                data: {
                    name: name,
                    passport_no: passport_no,
                    agent_code: agent_code,
                    phone_no: phone_no,
                    email: email,
                    dropdown_menu: dropdown_menu,
                    _token: _token,
                },
                success: function(data) {
                    console.log(data);
                    if (data.status == 200) {
                        thankuPopup.style.top = "50%"
                    }
                }
            });
        }
        });

        function reload(){
            location.reload();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\TECHCON SOLUTIONS\ikhlas_risk_advisor\resources\views/auth/register.blade.php ENDPATH**/ ?>