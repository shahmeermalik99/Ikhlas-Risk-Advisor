<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<?php /**PATH C:\Users\user\Desktop\TECHCON SOLUTIONS\ikhlas_risk_advisor\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>